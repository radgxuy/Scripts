sudo apt install snapd
sudo snap install rocketchat-server
# To configure go to  http://localhost:3000
# More information here: https://rocket.chat/docs/installation/manual-installation/ubuntu/snaps/
