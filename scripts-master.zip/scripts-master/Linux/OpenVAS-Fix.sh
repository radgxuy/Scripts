sudo apt-get purge --auto-remove openvas9
sudo apt-get update
sudo  apt-get install openvas9
openvas-manage-certs -f

