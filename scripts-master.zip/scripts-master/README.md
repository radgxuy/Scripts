# Useful Scripts
Scripts Used in various environments.

## Folder Root Explanation
- Chocolatey - Contains samples of some Chocolatey Scripts I use and how to deploy it remotely in a Microsoft AD enviroment.
- Linux - Contains Scripts That I use on Linux Systems. 
- Office 365 - Contains Scripts that I use on Office 365. 
- Printers - Contains Scripts that I use to deploy Printers. 
- Sonicwall - Cotains Scripts to Setup Sonicwall Mobile Connect. 
- Spiceworks - Contains Scripts used for Spiceworks Network Monitor, Inventory and Helpdesk. 
- Windows - Contains Scripts that I use on Windows Systems. 
- Datto - KB articles for Datto
- Sophos - Deployment Scripts for Sophos
