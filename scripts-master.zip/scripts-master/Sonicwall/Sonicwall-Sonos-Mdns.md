# Enabling MultiCast
https://www.sonicwall.com/en-us/support/knowledge-base/170505657227589 
# Enabling Multicast per interface
https://www.sonicwall.com/en-us/support/knowledge-base/170505301227319
# Enabling Multicast DNS
https://www.sonicwall.com/en-us/support/knowledge-base/170503725498663