#This script assumes you copied the SophosSetup.exe file to the C:\Temp folder
cd \Temp
SophosSetup.exe --products=antivirus;intercept --quiet