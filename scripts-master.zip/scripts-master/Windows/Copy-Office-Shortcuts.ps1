
Copy-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Outlook.lnk" C:\Users\Public\Desktop -Force
Copy-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Excel.lnk" C:\Users\Public\Desktop -Force
Copy-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\PowerPoint.lnk" C:\Users\Public\Desktop -Force
Copy-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Publisher.lnk" C:\Users\Public\Desktop -Force
Copy-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Word.lnk" C:\Users\Public\Desktop -Force
Copy-Item "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Access.lnk" C:\Users\Public\Desktop -Force